from random import choice

fortunes = ['You will become very rich', 'You will speak multiple languages', 'You will travel the world with the one you love', 'You have a secret admirer', 'Its not luck']
print(choice(fortunes))